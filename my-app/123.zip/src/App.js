import React from "react";

import logo from "./logo.svg";
import "./scss/app.scss";
import Header from "./componens/Header";
import Categories from "./componens/Categories";
import Sort from "./componens/Sort";
import PizzaBlock from "./componens/PizzaBlock";
import pizzas from "./assets/pizzas.json";



console.log(pizzas);

function App() {
  const[items , setItems] = React.useState();
   fetch("https://635ffd75ca0fe3c21aaa0637.mockapi.io/items")
   .then((res) => {
    return res.json();
  })
  .then((arr) => {
    console.log(arr);
  });

  return (
    <div className="wrapper">
      <Header />
      <div className="content">
        <div className="container">
          <div className="content_top">
            <Categories />
            <Sort />
          </div>
          <h2 className="content_title">Все пиццы</h2>
          <div className="content_items">
            {pizzas.map((obj) => (
              <PizzaBlock key={obj.id} {...obj} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
export default App;
